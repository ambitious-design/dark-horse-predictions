
import { useState, useEffect } from "react";
import { initializeApp } from "firebase/app";
import { getAuth, onAuthStateChanged } from "firebase/auth";
import { getFirestore, doc, getDoc } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export default function Home() {
  const [user, setUser] = useState(null);
  const [isVIP, setIsVIP] = useState(false);

  useEffect(() => {
    onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) {
        const snap = await getDoc(doc(db, "users", u.uid));
        if (snap.exists()) setIsVIP(snap.data().vip);
      }
    });
  }, []);

  const predictions = [
    { match: "Man United vs Chelsea", tip: "Man United Win", vip: false },
    { match: "Real Madrid vs Barca", tip: "Over 2.5 Goals", vip: true },
    { match: "PSG vs Lyon", tip: "Both Teams Score", vip: true },
  ];

  return (
    <div style={{ background: "black", color: "white", minHeight: "100vh", padding: 20 }}>
      <h1>🐎 Dark Horse Predictions</h1>

      <div>
        {predictions.map((p, i) => (
          <div key={i} style={{ margin: 10, padding: 10, border: "1px solid gray" }}>
            <h3>{p.match}</h3>
            {p.vip && !isVIP ? (
              <p>🔒 VIP Only</p>
            ) : (
              <p style={{ color: "lightgreen" }}>{p.tip}</p>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
